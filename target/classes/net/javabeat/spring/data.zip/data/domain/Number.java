package net.javabeat.spring.data.domain;

public enum Number {
	solo,
	duo
}
